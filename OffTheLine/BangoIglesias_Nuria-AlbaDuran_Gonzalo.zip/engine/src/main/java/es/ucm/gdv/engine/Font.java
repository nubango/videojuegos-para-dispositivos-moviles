package es.ucm.gdv.engine;

/*
 * Envuelve un tipo de letra para ser utilizado al escribir texto
 */

public interface Font {

}
